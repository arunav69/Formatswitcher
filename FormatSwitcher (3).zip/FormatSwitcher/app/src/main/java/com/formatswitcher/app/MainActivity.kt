package com.formatswitcher.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// Formats you can pick as the conversion target.
// Each maps to the ffmpeg codec args needed to produce that format.
enum class AudioFormat(val ext: String, val codecArgs: List<String>) {
    MP3("mp3", listOf("-codec:a", "libmp3lame", "-q:a", "2")),
    AAC_M4A("m4a", listOf("-codec:a", "aac", "-b:a", "192k")),
    WAV("wav", listOf("-codec:a", "pcm_s16le")),
    FLAC("flac", listOf("-codec:a", "flac")),
    OGG("ogg", listOf("-codec:a", "libvorbis", "-q:a", "5")),
    OPUS("opus", listOf("-codec:a", "libopus", "-b:a", "128k"))
}

private val AUDIO_EXTENSIONS = setOf(
    "mp3", "wav", "m4a", "aac", "flac", "ogg", "opus", "wma", "aiff", "aif"
)

data class LogLine(val text: String, val isError: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ConverterScreen()
                }
            }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ConverterScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var destUri by remember { mutableStateOf<Uri?>(null) }
    var targetFormat by remember { mutableStateOf(AudioFormat.MP3) }
    var isRunning by remember { mutableStateOf(false) }
    var formatMenuExpanded by remember { mutableStateOf(false) }
    val logLines = remember { mutableStateListOf<LogLine>() }

    val sourcePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            sourceUri = uri
        }
    }

    val destPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            destUri = uri
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Format Switcher", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        Button(onClick = { sourcePicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (sourceUri == null) "Pick source folder" else "Source: ${DocumentFile.fromTreeUri(context, sourceUri!!)?.name}")
        }
        Spacer(Modifier.height(8.dp))

        Button(onClick = { destPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (destUri == null) "Pick output folder" else "Output: ${DocumentFile.fromTreeUri(context, destUri!!)?.name}")
        }
        Spacer(Modifier.height(16.dp))

        ExposedDropdownMenuBox(
            expanded = formatMenuExpanded,
            onExpandedChange = { formatMenuExpanded = it }
        ) {
            OutlinedTextField(
                value = "Convert to .${targetFormat.ext}",
                onValueChange = {},
                readOnly = true,
                label = { Text("Target format") },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = formatMenuExpanded,
                onDismissRequest = { formatMenuExpanded = false }
            ) {
                AudioFormat.values().forEach { fmt ->
                    DropdownMenuItem(
                        text = { Text(".${fmt.ext}") },
                        onClick = {
                            targetFormat = fmt
                            formatMenuExpanded = false
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Button(
            enabled = sourceUri != null && destUri != null && !isRunning,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val src = sourceUri!!
                val dst = destUri!!
                isRunning = true
                logLines.clear()
                scope.launch {
                    convertFolder(context, src, dst, targetFormat) { line ->
                        logLines.add(line)
                    }
                    isRunning = false
                }
            }
        ) {
            Text(if (isRunning) "Converting..." else "Convert all files")
        }

        Spacer(Modifier.height(16.dp))
        if (isRunning) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }

        Text("Log", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
            items(logLines) { line ->
                Text(
                    text = line.text,
                    color = if (line.isError) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}

/**
 * Walks every file directly inside [sourceUri], skips anything already in
 * [target] format, and converts the rest into [destUri] using ffmpeg.
 */
suspend fun convertFolder(
    context: android.content.Context,
    sourceUri: Uri,
    destUri: Uri,
    target: AudioFormat,
    onLog: (LogLine) -> Unit
) = withContext(Dispatchers.IO) {
    val sourceDir = DocumentFile.fromTreeUri(context, sourceUri)
    val destDir = DocumentFile.fromTreeUri(context, destUri)

    if (sourceDir == null || destDir == null) {
        onLog(LogLine("Could not open one of the folders.", isError = true))
        return@withContext
    }

    // Walk every subfolder (album folders) and collect the actual song files.
    val files = mutableListOf<DocumentFile>()
    fun collect(dir: DocumentFile) {
        for (child in dir.listFiles()) {
            if (child.isDirectory) collect(child) else files.add(child)
        }
    }
    collect(sourceDir)

    if (files.isEmpty()) {
        onLog(LogLine("No files found in source folder (including subfolders)."))
        return@withContext
    }

    val cacheDir = File(context.cacheDir, "format_switcher").apply { mkdirs() }

    // Track output names we've used this run so two albums with a same-named
    // track ("01 Intro.mp3") don't clobber each other in the flat output folder.
    val usedNames = destDir.listFiles().mapNotNull { it.name }.toMutableSet()

    for (doc in files) {
        val name = doc.name ?: continue
        val ext = name.substringAfterLast('.', "").lowercase()

        if (ext !in AUDIO_EXTENSIONS) {
            onLog(LogLine("Skipped (not an audio file): $name"))
            continue
        }

        if (ext == target.ext) {
            onLog(LogLine("Skipped (already .${target.ext}): $name"))
            continue
        }

        val baseName = name.substringBeforeLast('.', name)
        var outName = "$baseName.${target.ext}"

        // Already converted previously? skip re-doing it.
        if (outName in usedNames) {
            if (destDir.findFile(outName) != null) {
                onLog(LogLine("Skipped (output already exists): $outName"))
                continue
            }
            // Name collision from a different album folder this run — disambiguate.
            val albumName = doc.parentFile?.name ?: "dup"
            outName = "$baseName ($albumName).${target.ext}"
        }
        usedNames.add(outName)

        val inCache = File(cacheDir, name)
        val outCache = File(cacheDir, outName)

        try {
            val inputStream = context.contentResolver.openInputStream(doc.uri)
            if (inputStream == null) {
                onLog(LogLine("Failed to read: $name", isError = true))
                continue
            }
            inputStream.use { input ->
                inCache.outputStream().use { output -> input.copyTo(output) }
            }

            if (outCache.exists()) outCache.delete()

            val command = mutableListOf("-i", inCache.absolutePath)
            command += target.codecArgs
            command += listOf("-y", outCache.absolutePath)

            val session = FFmpegKit.execute(command.joinToString(" ") {
                if (it.contains(" ")) "\"$it\"" else it
            })

            if (ReturnCode.isSuccess(session.returnCode)) {
                val newFile = destDir.createFile("audio/*", outName)
                if (newFile != null) {
                    context.contentResolver.openOutputStream(newFile.uri)?.use { out ->
                        outCache.inputStream().use { it.copyTo(out) }
                    }
                    onLog(LogLine("Converted: ${doc.parentFile?.name}/$name -> $outName"))
                } else {
                    onLog(LogLine("Converted but failed to save: $outName", isError = true))
                }
            } else {
                onLog(LogLine("ffmpeg failed on $name: ${session.failStackTrace ?: session.state}", isError = true))
            }
        } catch (e: Exception) {
            onLog(LogLine("Error on $name: ${e.message}", isError = true))
        } finally {
            inCache.delete()
            outCache.delete()
        }
    }

    onLog(LogLine("Done."))
}
