# Format Switcher

Android app: pick a source folder of audio files, pick an output folder, pick a target
format, hit Convert. Files already in the target format get skipped, so you can re-run
it safely on the same folder.

## How to build the APK

1. Install **Android Studio** (free, from developer.android.com/studio).
2. Unzip this project, then in Android Studio: `File > Open` → select the `FormatSwitcher` folder.
3. Let it sync (first sync downloads Gradle + the ffmpeg-kit-audio library, ~150MB, give it a few minutes on first run).
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. Studio will show a notification with a "locate" link to the generated `app-debug.apk` — that's your installable APK. Copy it to your phone and install it (you'll need to allow "install from unknown sources" once).

## Notes

- Supported target formats: mp3, m4a (aac), wav, flac, ogg, opus.
- The source folder is walked recursively — so a source folder full of album subfolders
  (each containing songs) works fine. Every converted song lands flat in the single
  output folder you picked, not mirrored into per-album subfolders.
- If two different albums have a same-named track (e.g. "01 Intro.mp3"), the second one
  gets its album name appended to the output filename so it doesn't overwrite the first.
- It reads any file with an audio-looking extension (mp3/wav/m4a/aac/flac/ogg/opus/wma/aiff) from the
  source folder — non-audio files are skipped and logged.
- Conversion runs entirely on-device via ffmpeg (no internet needed, no upload).
- The ffmpeg-kit-audio library (`com.arthenica:ffmpeg-kit-audio:6.0-2`) is used for
  transcoding. Its GitHub repo is archived, but the Maven Central artifact is still
  published and resolves fine — if a future Gradle sync ever fails to find it, that's
  the dependency to swap out.
- If you want it to also recurse into subfolders, or convert in place instead of to a
  separate output folder, say so and I'll adjust it.
